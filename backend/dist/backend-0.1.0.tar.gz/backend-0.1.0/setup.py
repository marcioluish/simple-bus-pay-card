# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['backend', 'backend.api.v1', 'backend.api.v1.endpoints']

package_data = \
{'': ['*']}

install_requires = \
['fastapi==0.63.0', 'uvicorn[standard]>=0.14.0,<0.15.0']

entry_points = \
{'console_scripts': ['backend = backend.main:main']}

setup_kwargs = {
    'name': 'backend',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'marcio',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
