# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['backend', 'backend.api.v1', 'backend.api.v1.endpoints', 'backend.database']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.22,<2.0.0',
 'fastapi==0.63.0',
 'psycopg2-binary>=2.9.1,<3.0.0',
 'pydantic>=1.8.2,<2.0.0',
 'uvicorn[standard]>=0.14.0,<0.15.0']

entry_points = \
{'console_scripts': ['backend = backend.main:main']}

setup_kwargs = {
    'name': 'backend',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'marcio',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
