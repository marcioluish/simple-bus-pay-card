from sqlalchemy import Column, Integer, String
from .database import Base


class Card(Base):
    __tablename__ = 'cards'

    id = Column(Integer, primary_key=True)
    value = Column(String, primary_key=False)    

    # def __init__(self, _id: str, sensor: str, value: str, toggle: str, timestamp: datetime):
    #     self.id = _id
    #     self.sensor = sensor
    #     self.value = value
    #     self.toggle = toggle
    #     self.timestamp = timestamp
